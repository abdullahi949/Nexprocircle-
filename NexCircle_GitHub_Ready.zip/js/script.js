// Reveal on scroll
  const io = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target);} });
  }, {threshold:0.12});
  document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

  // Roulette wheel
  const segments = ["DJ Mixing","Dance Challenge","Photography Task","Coding Puzzle","Mini Football Match","Podcast Interview","Art Challenge"];
  const wheel = document.getElementById('wheel');
  const btn = document.getElementById('spinBtn');
  const result = document.getElementById('wheelResult');
  let currentRotation = 0;
  const segAngle = 360/segments.length;

  btn.addEventListener('click', () => {
    btn.disabled = true;
    result.innerHTML = "Spinning…";
    const idx = Math.floor(Math.random()*segments.length);
    // land pointer (top, 0deg) on middle of chosen segment
    const targetMid = idx*segAngle + segAngle/2;
    const fullSpins = 5*360;
    const newRotation = currentRotation + fullSpins + (360 - (currentRotation % 360)) + (360 - targetMid);
    currentRotation = newRotation;
    wheel.style.transform = `rotate(${currentRotation}deg)`;
    setTimeout(()=>{
      result.innerHTML = `Your 20-minute challenge: <b>${segments[idx]}</b>`;
      btn.disabled = false;
    }, 4300);
  });
  // Static GitHub Pages membership demo.
  // This shows a confirmation only; it does not save data to a server.
  const joinBtn = document.getElementById('joinBtn');
  const joinEmail = document.getElementById('joinEmail');
  const joinForm = document.querySelector('.join-form');

  if (joinBtn && joinEmail && joinForm) {
    const demoMsg = document.createElement('p');
    demoMsg.style.cssText = 'display:none;margin-top:16px;font-weight:700;';
    demoMsg.textContent = "You're on the list — see you Saturday. 👊";
    joinForm.insertAdjacentElement('afterend', demoMsg);

    joinBtn.addEventListener('click', () => {
      if (!joinEmail.value || !joinEmail.checkValidity()) {
        joinEmail.focus();
        return;
      }
      joinEmail.value = '';
      demoMsg.style.display = 'block';
    });
  }

