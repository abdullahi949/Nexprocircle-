# NexCircle

**Move. Connect. Create. Belong.**

GitHub Pages-ready static prototype of the NexCircle website.

## Enable GitHub Pages

1. Create a GitHub repository named `NexCircle`.
2. Upload all files in this folder to the repository.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save.
7. Open the GitHub Pages URL provided by GitHub.

## Structure

```text
NexCircle/
├── index.html
├── css/style.css
├── js/script.js
├── assets/images/
├── README.md
└── .gitignore
```

The visual design, responsive layout, Roulette wheel, navigation, sections and scroll animations are preserved from the supplied prototype.

The membership form is a static demo on GitHub Pages. It does not save member data. The PHP/MySQL version is for server hosting such as the planned Safaricom deployment.

## Local preview

Open `index.html` directly in a browser, or use the VS Code Live Server extension.
